The Safety Plan — Homefront Kit Preview

Files included:
- public/gallery/kit-homefront.jpg

Install:
1) Unzip this file at your project root (same folder as `package.json`).
2) It will create/merge into `public/gallery/`.
3) Visit http://localhost:3000/kits/homefront — the preview will display automatically.

Notes:
- You can replace this image anytime with a real product photo.
- Alternative names supported: public/gallery/homefront.jpg or public/homefront.jpg/webp/avif/png.
